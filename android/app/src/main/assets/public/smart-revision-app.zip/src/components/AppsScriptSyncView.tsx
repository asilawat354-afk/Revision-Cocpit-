import React, { useState } from "react";
import { 
  ArrowLeft,
  FileSpreadsheet, 
  Code2, 
  Copy, 
  Check, 
  ExternalLink,
  Sparkles,
  Download
} from "lucide-react";

interface AppsScriptSyncViewProps {
  onGoBack: () => void;
  onExportCSV: () => void;
  backTitle?: string;
}

export const AppsScriptSyncView: React.FC<AppsScriptSyncViewProps> = ({
  onGoBack,
  onExportCSV,
  backTitle = "वापस"
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  const appsScriptCode = `/**
 * =========================================================================
 * स्मार्ट रिवीज़न कॉकपिट | Google Apps Script Automation Engine (v2.0)
 * =========================================================================
 * 1. 2-Step Mandatory Foundation (1-Day -> 3-Day)
 * 2. Scientific Spaced Repetition (Easy: +21d, Medium: +12d, Hard: +4d)
 * 3. Dynamic Daily Quota & Vacation Pause (0 Extra Backlog)
 * 4. Auto-Leveling Load Balancer for 30-Day Heatmap
 * =========================================================================
 */

function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🎯 स्मार्ट कॉकपिट (Smart Cockpit)')
    .addItem('📊 आज का कोटा जनरेट करें (Get Today Quota)', 'generateTodayQuota')
    .addItem('⚡ ऑटो-लेवलिंग लोड स्मूथ करें (Smooth Schedule)', 'autoLevelSchedule')
    .addItem('⏸️ पॉज़ / वेकेशन मोड (Shift All Dates)', 'promptVacationShift')
    .addItem('🔄 424 पुराना बैकलॉग आर्काइव करें (Debt Reset)', 'archiveLegacyDebt')
    .addToUi();
}

/**
 * 1-क्लिक में आज के लिए दैनिक कोटा (Daily Quota) फ़िल्टर करना
 */
function generateTodayQuota() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('MasterDatabase') || ss.getActiveSheet();
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  
  const today = new Date();
  today.setHours(0,0,0,0);
  
  const nextDueDateCol = headers.indexOf('अगली तारीख');
  const statusCol = headers.indexOf('स्थिति');
  
  let dueCount = 0;
  for (let i = 1; i < data.length; i++) {
    const rowDate = new Date(data[i][nextDueDateCol]);
    const status = data[i][statusCol];
    if (status !== 'Archived' && rowDate <= today) {
      dueCount++;
    }
  }
  
  SpreadsheetApp.getUi().alert('🎯 आज के सक्रिय ड्यू लेक्चर्स: ' + dueCount + '\\nकोकपिट दैनिक कोटे के अनुसार शीर्ष 5-8 लेक्चर्स का अध्ययन करें!');
}

/**
 * छुट्टी या अवकाश के बाद बिना बैकलॉग के सभी तारीखों को आगे खिसकाना
 */
function promptVacationShift() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.prompt('⏸️ वेकेशन मोड', 'आप कितने दिन अवकाश पर थे? (संख्या दर्ज करें, उदा. 4):', ui.ButtonSet.OK_CANCEL);
  
  if (response.getSelectedButton() == ui.Button.OK) {
    const days = parseInt(response.getResponseText());
    if (isNaN(days) || days <= 0) {
      ui.alert('कृपया वैध दिनों की संख्या दर्ज करें।');
      return;
    }
    
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('MasterDatabase') || ss.getActiveSheet();
    const data = sheet.getDataRange().getValues();
    const nextDueDateCol = data[0].indexOf('अगली तारीख');
    
    for (let i = 1; i < data.length; i++) {
      const cell = sheet.getRange(i + 1, nextDueDateCol + 1);
      const val = cell.getValue();
      if (val instanceof Date) {
        val.setDate(val.getDate() + days);
        cell.setValue(val);
      }
    }
    ui.alert('✅ सफलता: सभी ' + (data.length - 1) + ' लेक्चर्स ' + days + ' दिन आगे खिसका दिए गए। कोई बैकलॉग नहीं!');
  }
}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(appsScriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-2xl border border-stone-200/90 shadow-2xs">
        <div className="flex items-center space-x-2.5">
          <button
            type="button"
            onClick={onGoBack}
            aria-label="वापस जाएं"
            className="h-8 w-8 sm:w-auto px-0 sm:px-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 border border-stone-200 cursor-pointer shadow-2xs shrink-0"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">{backTitle}</span>
          </button>

          <div className="h-4 w-px bg-stone-200 hidden sm:block" />

          <div className="flex items-center space-x-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-900 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-black text-stone-900 tracking-tight leading-tight truncate">
                Google Sheets Apps Script एकीकरण (v2.0)
              </h2>
              <p className="text-[11px] text-stone-500 truncate">
                शीट ऑटोमेशन मेनू, ऑटो-लेवलिंग और वेकेशन मोड स्क्रिप्ट
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2 self-end sm:self-auto shrink-0">
          <button
            type="button"
            onClick={onExportCSV}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-stone-900 hover:bg-stone-800 text-white flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>डेटा CSV एक्सपोर्ट करें</span>
          </button>
        </div>
      </div>

      {/* Integration Guide Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-1.5">
          <div className="w-7 h-7 rounded-lg bg-stone-100 text-stone-800 font-bold text-xs flex items-center justify-center">
            1
          </div>
          <h4 className="text-xs font-bold text-stone-900">Google Sheet खोलें</h4>
          <p className="text-[11px] text-stone-600">
            अपनी मास्टर स्प्रेडशीट खोलें और मेनू बार में <strong>Extensions &gt; Apps Script</strong> पर क्लिक करें।
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-1.5">
          <div className="w-7 h-7 rounded-lg bg-stone-100 text-stone-800 font-bold text-xs flex items-center justify-center">
            2
          </div>
          <h4 className="text-xs font-bold text-stone-900">कोड पेस्ट करें</h4>
          <p className="text-[11px] text-stone-600">
            नीचे दिए गए कोड को कॉपी करें और Apps Script संपादक में पेस्ट करके <strong>Save (Ctrl+S)</strong> दबाएं।
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-1.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-800 font-bold text-xs flex items-center justify-center">
            3
          </div>
          <h4 className="text-xs font-bold text-stone-900">कॉकपिट मेनू तैयार</h4>
          <p className="text-[11px] text-stone-600">
            शीट को रिफ्रेश करें! <strong>'🎯 स्मार्ट कॉकपिट'</strong> मेनू से 1-क्लिक में कोटा व वेकेशन शिफ्ट चलाएं।
          </p>
        </div>
      </div>

      {/* Script Code Viewer */}
      <div className="bg-stone-900 rounded-2xl p-4 shadow-xl border border-stone-800 space-y-3">
        <div className="flex items-center justify-between border-b border-stone-800 pb-2.5">
          <div className="flex items-center space-x-2 text-stone-300 text-xs font-mono">
            <Code2 className="w-4 h-4 text-emerald-400" />
            <span>Code.gs (Apps Script Engine)</span>
          </div>

          <button
            type="button"
            onClick={copyToClipboard}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              copied 
                ? "bg-emerald-600 text-white" 
                : "bg-white/10 hover:bg-white/20 text-stone-200 border border-white/15"
            }`}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>कॉपी हो गया!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>कोड कॉपी करें</span>
              </>
            )}
          </button>
        </div>

        <pre className="text-stone-300 font-mono text-xs overflow-x-auto p-2 bg-stone-950/70 rounded-xl leading-relaxed max-h-[460px] overflow-y-auto">
          <code>{appsScriptCode}</code>
        </pre>
      </div>
    </div>
  );
};
