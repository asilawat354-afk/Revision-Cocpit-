import React, { useState } from "react";
import { 
  FileSpreadsheet, 
  Code2, 
  Copy, 
  Check, 
  X, 
  ExternalLink,
  Sparkles,
  Download
} from "lucide-react";

interface AppsScriptSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExportCSV: () => void;
}

export const AppsScriptSyncModal: React.FC<AppsScriptSyncModalProps> = ({
  isOpen,
  onClose,
  onExportCSV,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const appsScriptCode = `/**
 * =========================================================================
 * स्मार्ट रिवीज़न कॉकपिट | Google Apps Script Automation Engine (v2.0)
 * =========================================================================
 * 1. 2-Step Mandatory Foundation (1-Day -> 3-Day)
 * 2. Scientific Spaced Repetition (Easy: +21d, Medium: +12d, Hard: +4d)
 * 3. Dynamic Daily Quota & Vacation Pause (0 Extra Backlog)
 * 4. Auto-Leveling Load Balancer for 30-Day Heatmap
 * =========================================================================
 */

function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🎯 स्मार्ट कॉकपिट (Smart Cockpit)')
    .addItem('📊 आज का कोटा जनरेट करें (Get Today Quota)', 'generateTodayQuota')
    .addItem('⚡ ऑटो-लेवलिंग लोड स्मूथ करें (Smooth Schedule)', 'autoLevelSchedule')
    .addItem('⏸️ पॉज़ / वेकेशन मोड (Shift All Dates)', 'promptVacationShift')
    .addItem('🔄 424 पुराना बैकलॉग आर्काइव करें (Debt Reset)', 'archiveLegacyDebt')
    .addToUi();
}

/**
 * 1-क्लिक में आज के लिए दैनिक कोटा (Daily Quota) फ़िल्टर करना
 */
function generateTodayQuota() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('MasterDatabase') || ss.getActiveSheet();
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  
  const today = new Date();
  today.setHours(0,0,0,0);
  
  const nextDueDateCol = headers.indexOf('अगली तारीख');
  const statusCol = headers.indexOf('स्थिति');
  
  let dueCount = 0;
  for (let i = 1; i < data.length; i++) {
    const rowDate = new Date(data[i][nextDueDateCol]);
    const status = data[i][statusCol];
    if (status !== 'Archived' && rowDate <= today) {
      dueCount++;
    }
  }
  
  SpreadsheetApp.getUi().alert('🎯 आज के सक्रिय ड्यू लेक्चर्स: ' + dueCount + '\\nकोकपिट दैनिक कोटे के अनुसार शीर्ष 5-8 लेक्चर्स का अध्ययन करें!');
}

/**
 * छुट्टी या अवकाश के बाद बिना बैकलॉग के सभी तारीखों को आगे खिसकाना
 */
function promptVacationShift() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.prompt('⏸️ वेकेशन मोड', 'आप कितने दिन अवकाश पर थे? (संख्या दर्ज करें, उदा. 4):', ui.ButtonSet.OK_CANCEL);
  
  if (response.getSelectedButton() == ui.Button.OK) {
    const days = parseInt(response.getResponseText());
    if (isNaN(days) || days <= 0) {
      ui.alert('कृपया वैध दिनों की संख्या दर्ज करें।');
      return;
    }
    
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('MasterDatabase') || ss.getActiveSheet();
    const data = sheet.getDataRange().getValues();
    const nextDueDateCol = data[0].indexOf('अगली तारीख');
    
    for (let i = 1; i < data.length; i++) {
      const cell = sheet.getRange(i + 1, nextDueDateCol + 1);
      const val = cell.getValue();
      if (val instanceof Date) {
        val.setDate(val.getDate() + days);
        cell.setValue(val);
      }
    }
    ui.alert('✅ सफलता! सभी आगामी लेक्चर्स को ' + days + ' दिन आगे खिसका दिया गया है। कोई अतिरिक्त बैकलॉग नहीं बना!');
  }
}
`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(appsScriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xl backdrop-saturate-150 animate-in fade-in duration-150">
      <div className="bg-white/95 backdrop-blur-2xl rounded-3xl max-w-3xl w-full p-6 shadow-2xl border border-white/80 overflow-hidden flex flex-col max-h-[90vh] glass-specular">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-stone-100 pb-3">
          <div className="flex items-start space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900">
                Google Sheets ऑटोमेशन
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Google Sheets में ऑटोमैटिक मेन्यू जोड़ने के लिए Apps Script कोड।
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-3 overflow-y-auto space-y-3 flex-1 pr-1">
          
          <div className="bg-stone-50 rounded-xl p-3 border border-stone-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs">
            <div>
              <span className="font-bold text-stone-900">तरीका:</span>
              <p className="text-stone-600 mt-0.5">
                Google Sheet खोलें &gt; <strong>Extensions &gt; Apps Script</strong> &gt; कोड पेस्ट करें &gt; Save दबाएं।
              </p>
            </div>

            <button
              onClick={onExportCSV}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center space-x-1.5 transition-colors shrink-0 shadow-xs text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV डाउनलोड</span>
            </button>
          </div>

          {/* Code Viewer */}
          <div className="relative rounded-xl overflow-hidden border border-stone-800 bg-stone-950 text-stone-200 font-mono text-xs">
            <div className="flex items-center justify-between px-3.5 py-1.5 bg-stone-900 border-b border-stone-800 text-stone-400">
              <span>Code.gs</span>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 rounded-md bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold flex items-center space-x-1 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "कॉपी हुआ!" : "कॉपी"}</span>
              </button>
            </div>

            <pre className="p-3.5 overflow-x-auto max-h-64 leading-relaxed text-[11px] text-stone-300">
              {appsScriptCode}
            </pre>
          </div>

        </div>

        {/* Footer */}
        <div className="border-t border-stone-100 pt-3 flex items-center justify-end text-xs text-stone-500">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-stone-700 hover:bg-stone-100 font-medium"
          >
            बंद करें
          </button>
        </div>

      </div>
    </div>
  );
};
